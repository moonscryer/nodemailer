export interface mailData {
  naam: string;
  voornaam: string;
  geboortedatum: string;
  haarkleur: string;
  lengte: string;
  geslacht: string;
  opmerking: string;
}
