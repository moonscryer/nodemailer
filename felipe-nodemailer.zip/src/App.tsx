import Form from "./components/Form";

const App = () => {
  return (
    <div>
      <Form />
    </div>
  );
};

export default App;
